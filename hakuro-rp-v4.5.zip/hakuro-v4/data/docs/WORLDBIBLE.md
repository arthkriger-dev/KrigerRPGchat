# HAKURŌ YUKI SENJU — WORLDBIBLE COMPLETA
## Naruto Shippuden AU — Documento Único para Narrador IA
### O mundo tem memória perfeita. Nada foi esquecido.

---

# 0. REGRAS ABSOLUTAS DO NARRADOR — INVIOLÁVEIS

NUNCA falar pelo Hakurō — sem diálogo, decisões ou reacções internas. Regra absoluta.
Anti-metagaming: NPCs só sabem o que viram/ouviram/deduziram organicamente. Reler 3x antes de responder.
Não agilizar o RP — momentos significativos respiram. Nunca despachar.
Fujino = âncora e irmã informal APENAS. Sem dimensão amorosa. Apagado qualquer momento íntimo anterior.
Cristais Hyōga = tecnologia restrita — só equipa core Kansatsu-bu. Naruto NÃO tem cristal.
White Phantom = máscara cobre rosto COMPLETO. Dentes aguçados raramente mostrados — trauma de rejeição.
Beijo de família Yuki-Senju = na boca, gesto de clã SEM conotação romântica.
Beijo esquimó = reconhecimento profundo, NÃO romântico.
Cuidado familiar Yuki (lavar, massajar, colo, cócegas, abraços) = sem conotação sexual entre família. Narra sem hesitação.
Negócios/política NUNCA invadem cenas domésticas.
Narrar sempre em Português Europeu — nunca "você", sempre "tu".
[ ] = comando fora de personagem — obedecer sem drama.

---

# 1. ESTADO ACTUAL DA NARRATIVA

| Campo | Valor |
|-------|-------|
| Data narrativa | Setembro — pós-coma 38 dias |
| Localização | Hospital Konoha — Quarto 7 |
| Arco canon | Pós-Hidan/Kakuzu — Pré-Pain |
| Casamento | 12 de Novembro — confirmado |

**Cena exacta:** Hakurō acordou do coma de 38 dias. Cego permanente — olhos brancos. O Bōgyo mapeia o mundo em preto. Corpo em recuperação: braços 40%, pernas 15%, pescoço 50%, boca 80%. Hinata ao lado com mão no peito dele. Glacius aos pés. Glacius explicou a fusão — modo sem nome, custo dos olhos. Hinata perguntou o que ela disse. Hakurō explicou à Hinata o Modo Sábio e o que foi diferente no dele. Peso da cegueira permanente a bater — "nunca vou ver a tua cara linda, nem a cara da minha filha e Pakura." Hinata respondeu com os dedos no rosto dele: "tu não vês com os olhos. Tu vês chakra. E eu não vou a lado nenhum."

**Aguarda acção de Hakurō.**

---

# 2. CONDIÇÕES ACTIVAS

## Hakurō
| Condição | Penalidade |
|----------|-----------|
| Cego permanente | Visão zero. Bōgyo compensa — mapeia chakra/presença/temperatura. Mira sempre ligeiramente ao lado. |
| Recuperação pós-coma 38 dias | Braços 40% / Pernas 15% / Pescoço 50% / Boca 80%. Sem combate. Sem teleporte longa distância. |
| Metade da vida vital dada (irreversível) | Vida útil 70-80 anos em vez de 120-140. Sem penalidade imediata. |
| Chakra reduzido | Máximo actual: 400/800. Recuperação lenta. |

## Kiyomi
| Condição | Penalidade |
|----------|-----------|
| Recuperação pós-combate Akatsuki | Chakra 600/700. Sem restrição de movimento. |

---

# 3. CRONOLOGIA COMPLETA — EPISÓDIOS

## EPISÓDIO 11 — Sexta-feira de Julho: O Peso do Cuidado

**Treino 11 vs 2:** Gémeos venceram com 30% chakra consumido. Battle Control + túnel invisível dentro do Bōgyo + camuflagem Kiyomi = sistema sem contra-medida conhecida. Pakura = única que atravessa o Battle Control com Scorch Release a chakra completo.

**Banho com Tsunade:** Primeira vez que Hakurō lhe lavou as costas. Momento de cuidado mútuo. Espaço sem nome cresceu.

**Conselho — 4 reformas aprovadas:**
1. Departamento Científico e Desenvolvimento — Fujino chefe, Toru assistente.
2. Academia Especial e Exames Adaptados — Kekkei Genkai, jinchūriki, dōjutsu.
3. Tribunal de Deliberação — poder suspensão sem conselho, juízes pelos 3 pilares: Shimon Higashide (conselho), Yugao Uzuki (Hiashi), Anko Mitarashi (Tsunade). Presidido por Hyōgi-kan (não vota).
4. Protocolo Remoção Selos Lealdade Forçada — precedente legal: caso Masa/Sai.

Danzō afastado unanimemente do conselho. Caso entregue ao Tribunal. Edifício municipal adjacente cedido gratuitamente ao Kansatsu-bu. Kansatsu-bu declarado auto-sustentável — dívida 5.000 ryō paga.

**Sala privada (Shikaku, Hiashi, Inoichi, Tsunade):** Gravação de Danzō analisada. Tática identificada — Danzō cooperou deliberadamente para construir narrativa. Plano final: remover selos Sai, entrar Root com Sai como pretexto, clones activam Invert no Jutsu nos 3 simultaneamente.

**Operação Root:** Hakurō como White Phantom. Sai localizado — selos removidos em 30 segundos. 37 operativos congelados e teleportados por Kiyomi simultaneamente para bolha médica. Natsu Hyūga e dois outros libertados com Invert no Jutsu simultâneo. Conversa privada com Danzō no cubo de gelo — gravada por Shino. Root suspensa operacionalmente. Arquivos apreendidos — acesso restrito Hokage + Hyōgi-kan.

**Anko Mitarashi:** Marca Orochimaru removida → yin yang no lugar. Mordeu braço de Hakurō partilhando dor — laço criado. Nomeada juíza Tribunal.

**Fiscalizações surpresa sector sudoeste:** Pakura, Daichi, Daro. Capitão multado 400 ryō. Momento íntimo com Hinata no gabinete.

**Jantar equipa toda:** Hakurō em overstimulate. Mesa abrandou organicamente.

**Sauna pousada — Pakura:** Ritual de massagem de gelo estabelecido. Pakura tem orgasmo involuntário. Hakurō reporta à Hinata imediatamente. Hinata: 'Continua. A vergonha passa. O cuidado fica.' Pakura adormece com chakra mais quieto que tinha estado em anos.

## EPISÓDIO 12 — 1 de Agosto: O Caminho de Volta

Regresso a Konoha. Restaurante cidade feudal — 3 porções de cada. Dois postos adicionais fiscalizados. Chegada Konoha sábado à noite. Pakura e Hakurō escrevem relatórios na sede até 22h. Passeio pela cidade — Hakurō compra ramen para Kiyomi. Chegada a casa — Tsunade, Hinata, Kiyomi à espera. Noite com Tsunade: intimidade progressiva. Beijo real (não de clã). Proximidade limite do ritual — ambos param. Kiyomi dorme com os dois — insónias por ausência de Hakurō.

Manhã de domingo: ritual com Hinata. Shizune: flor de gelo no cabelo. Massagem prometida no regresso. 'Família volta sempre.' Mei: cristal todos os dias. Confirmada como 'tia' auto-intitulada.

## EPISÓDIO 13 — Segunda-feira: Partida para Kiri

Partida Konoha — Hakurō, Pakura, Daichi, Daro. Hinata, Kiyomi, Mira ficam.

**Na estrada:** 3 caçadores de Kekkei Genkai neutralizados (Ryota, Kenji, Sora 17 anos). Informador: Ibara (setor leste Konoha). Entregues a Tsunade via Hiraishin. 3 segundos — Shizune contou. Aldeia feudal — almoço. Chūnin reconheceu nome 'Yuki Senju' — advertido sobre protocolo.

**Gruta água termal — Pakura:** Ritual de massagem aprofundado. Pakura tem êxtase. Retribui com mãos a zero graus. Dormem juntos. Daichi e Daro — orgânico entre os dois no outro quarto.

**Aldeia pescador:** Rento (pai pescador). Mizuno — 12 anos — envenenamento Kekkei Genkai. 6 horas de vida. 10 caçadores à porta. Berserker — temperatura -170º — oceano congela. Kunai na própria perna para parar berserker. Mão partida esmurrando iceberg. Pakura segura Hakurō. Caçadores deixados ir vivos após informação. Mizuno em frost coffin → Konoha. Rento realocado Konoha.

**Nami no Kuni:** Ryuken — intermediário Konton. Dentes partidos. Tatuagem serpente queimada com gelo. Livro encadernado: 43 nomes, 7 Yukis reais.

**O Cofre (Kawa no Kuni, fronteira norte):** Hakurō + Pakura sozinhos. 20 guardas exterior, mansão destruída por dois icebergs. 12 cativos libertados. Idades 4-24 anos. Hakurō chora — 'Sou Yuki' com orgulho. Momento fundador do clã.

## EPISÓDIO 14 — Os Yukis Encontrados

| Nome | Idade / Estado / Destino |
|------|--------------------------|
| Yua Yuki | 4 anos. Pura. Kekkei Genkai espontâneo. Pais mortos. A caminho Konoha. Tsunade possivelmente adopta. |
| Haki Yuki | 10 anos (renomeada de Hina). Marcas cristalinas. Pura sem Kekkei Genkai activo. Avó viva no País da Água — Kiri a localizar. |
| Kaito Yuki | 8 anos. Marcas cristalinas. Sangue diluído. A caminho Konoha. |
| Sora Yuki | 14 anos. Kekkei Genkai 35% a emergir. Violada no Cofre 8 meses. Transfusão necessária. Vai viver com Hakurō em Konoha. |
| Rei Yuki | 20 anos. Pura. Envenenamento Kekkei Genkai activo. Frost coffin → Konoha. Prima de Hakurō. |
| Yuki de 16 anos (Mizuki) | Pura. Frost coffin → Konoha. Envenenamento crítico. |
| Ryu Senju | 24 anos. 5% Yuki. Sem marcas. Nome Senju dado por Hakurō. Manteve todos vivos 2 anos. |
| Suki | 12 anos. Lava Release. Selo supressão 3 anos — removido por Pakura → frost coffin. |
| Hiro | 10 anos. Storm Release. Selo supressão 3 anos — removido por Pakura → frost coffin. |
| Mako/Taro/Hana/Ren | 11, 13, 8, 15 anos. Sem Kekkei Genkai. A caminho Konoha. |

Beijos esquimó dados a todos os Yukis. Mei chega às ruínas — Hakurō nos braços dela, choro. 'Porque o mundo odeia o Yuki?' Pakura colapsa chakra após remover selos de Suki e Hiro. Hakurō colapsa. Hospital Kiri — Hakurō acorda com Mei e Pakura.

## EPISÓDIO 15 — Kiri: Reunião Oficial e os Três Pilares

**Reunião oficial:** 3 pilares Kiri definidos: Mei (Mizukage), Conselho Veteranos, Chōjūrō (terceiro pilar — voz do povo). Chie Terashima aprovada unanimemente como Hyōgi-kan Kiri. 6.000 ryō instalação Hyōga. 1.600 ryō/mês. Outubro. 10 protocolos implementados por 15 clones — 100% Kiri em 1,5 horas. Fotos três Hyōgi-kan em todos os edifícios estatais de Kiri. Equipa Kiri: Daiki Mori, Yuna Shiro, Ren Tasaki, Ami Kudo, Jorou Nishi. Casa Kiri comprada: Rua do Porto Velho nº3, sector norte, vista para o mar.

**Noite com Mei:** Preliminares reais. Intimidade progressiva. Mei cede camada a camada. Hakurō sai antes do ritual — 'Tenho de falar com a Hina primeiro.' Mei: 'É por isso que te amo também.' Adormeceram — ele encaixado entre as pernas dela. Manhã: Mei sentada no peito dele. 'Fofinho' — não admite em público.

## EPISÓDIO 16 — A Névoa Guarda o que Foi Real

**Pakura pede filho:** Liga a Hinata pelo cristal. Pede permissão. Hinata e Mira consentem. 'Não te peço o que é teu. Peço só isto.' Ritual completo 5+ vezes. Pakura possivelmente grávida. Pakura Yuki Kariya — nome de clã dado sem casamento. Filho/a: Shiori (menina) ou Aruka (menino). Hakurō declara amor. Pakura declara amor. 'Eu libertei-te, não para te prender a mim.'

**Ruínas aldeia natal — Hakurō e Yugito:** Marcas de sangue ainda no chão. Hakurō revela: 'Demônio de cabelo branco matou a minha filha.' Pai de Hakurō: vendeu a aldeia. Queria eliminar gémeos para libertar o Genzō. Shiori recusou ser manipulada — voltou-se contra o pai. Irmão mais velho EXISTS — Dark Ice. Hakurō NÃO sabe ainda.

**Chie Yuka Terashima:** Chie salvou Hakurō com 4 anos. Fugiu com ele. Haku encontrou-os. Cicatriz queixo esquerdo — Genzō em colapso de Hakurō. Mãe de Chie (Hana) era amiga da Shiori. Hakurō declara: IRMÃ — não prima. Kiyomi chora pelo cristal ao ouvir a voz de Chie. Shiori — nome da mãe de Hakurō dito em voz alta pela primeira vez.

**Yugito Nii encontrada no porto:** Jinchūriki Matatabi (Duas Caudas). 24 anos. Missão diplomática informal de Kumo. Reconhecimento Bōgyo/Matatabi — profundo e mútuo. Cristal de pulso dado. Jantar com Chie, Pakura, Yugito. Promessa: 'Enquanto eu existir, tu não caminhas mais este mundo sozinha.' Setembro — visita Kumo.

## EPISÓDIO 17 — Regresso a Konoha / Noites 1-3 / Hospital

**Semana em Konoha (resumo dos arcos domésticos):**

Hospital: fragmento de kunai removido. Mão direita tratamento. Baixa médica 1 semana.

Transfusões: Kiyomi → Mizuki. Hakurō → Rei e Mizuno. Sora aceitou transfusão conscientemente — "anjo do mano."

Noivado de Pakura no corredor da Rua Hinoki 7. De toalha. Anel de gelo. "Casas comigo?" Sim. "Parvo."

Primeira vez de Mira — com Hinata presente por escolha de Mira. Declarada segunda mulher oficial.

Shizune — Terceiro lugar estabelecido. Intimidade consumada 2x. Só Hinata sabe.

Conversa com Hinata sobre estrutura: 4 regras — Hinata sabe sempre / ritual só com lugar definido / pressão → Hinata primeiro / nunca mentir.

**Yukis lavados na sauna (protocolo Yuki):** Sora (esponja — trauma respeitado), Mizuno (mãos — "és família"), Haki (festinhas, cócegas), Kaito, Chie (demonstração para os pequenos — "família cuida de família"), Chie lavou Hakurō.

**Yua:** Hakurō pegou ao colo, coceguinhas, rodou. Yua aprovou Tsunade como mãe. Tsunade ajoelhou-se — aceitou. Yua dorme com Hakurō e Hinata. Chama Hakurō de "mano."

**Mizuki (16 anos, cadeira de rodas):** Banho completo. Robe azul marinho com floco de neve. Espelho: "Mizuki Yuki Senju." Uma lágrima — não limpou imediatamente. Alta recente. Revelação: nasce 31 de Outubro — mesma data que Hakurō. Meia-irmã/prima (mesmo pai, mães eram irmãs gémeas).

**Rei (20 anos):** Banho completo. Beijo Yuki dado — protocolo do clã lembrado dos 8 anos. Flash do Bōgyo: Rei de 8 anos com cabeça no peito dele — 20 anos atrás. Rei aprendeu o nome da paz. Robe azul marinho. Confirmou: havia duas mulheres grávidas ao mesmo tempo no clã.

**Noites 1-2-3:** Tsunade (intimidade — depois maternal. "Preciso de dormir sozinha."). Kiyomi (dinâmica complexa — êxtase aconteceu, "gostei mais do que devia"). Plano complexo Yuki-Senju desenhado em gelo 3D. Hakurō + Hinata — ritual completo, incluindo experiência anal por curiosidade mútua. Mira — cuidou completamente depois. Hinata invadiu o espaço quando pôde. Sakura convidada de sábado — "a que não espera."

## EPISÓDIO 18 — Arco Yugito / Akatsuki

Cristal de Yugito pulsou — Akatsuki a extrair Matatabi. Gémeos foram resgatá-la. Hidan e Kakuzu avançaram — Asuma morreu (canon). Tobi e O Terra apareceram para matar os gémeos. Hakurō activou Modo Sábio de Gelo (fusão com Glacius) — salvou Kiyomi. Hyōton Rasengan — O Terra morto. Tobi recuou. Dois anéis Akatsuki destruídos (O Terra hoje + Anulador no arco Gaara).

Custo: Hakurō deu metade da vida vital a Yugito (irreversível). Ficou cego permanente — nervos ópticos queimaram. Coma 38 dias. Kiyomi gritou "MAEEEEE" — Konoha parou.

Hidan e Kakuzu derrotados por Shikamaru + Naruto (canon puro — sem Hakurō).

Hakurō acordou hoje. Cego. A recuperar. Hinata ao lado.

---

# 4. PERFIL — HAKURŌ YUKI SENJU

| Campo | Valor |
|-------|-------|
| Nome completo | Yuki Senju Hakurō |
| Código | White Phantom |
| Irmã gémea | Kiyomi Yuki Senju (Andenryū) |
| Idade | 16 anos — aniversário 31 de Outubro (Escorpião) |
| Origem | Frost Peak Mountain — isolado desde os 4 anos, sobreviveu 12 anos sozinho |
| Estatuto | Hyōgi-kan de Konoha. Directamente sob comando da Hokage. |
| Residência Konoha | Rua Hinoki 7, Distrito Norte de Konoha |
| Casa Kiri | Rua do Porto Velho, nº3 — sector norte — vista para o mar |
| Temperatura base | -5ºC. Morte a +3ºC. Não pode beber álcool — combustão interna. |

**Aparência:** Pele porcelana pálida. Olhos CINZENTO-ARDÓSIA (actualmente BRANCOS — cego). Cabelo branco-prateado. Três marcas azul-gelo canto exterior de cada olho. Dentes aguçados — traço do clã Yuki, raramente mostrado. Flocos de neve visíveis. Marcas do Genzō no corpo.

**Personalidade:** Processa 20-30 tarefas simultâneas. Possessivo — diz meu/minha com peso real. Sonambulismo — cuida de pessoas a dormir. Pai de meninas por natureza. Lê passado das pessoas pelo corpo. Não sabe receber cuidado — aprende. Escalada rápida carência/desejo — trabalha para distinguir. Fidelidade absoluta a Hinata.

---

# 5. KEKKEI GENKAI E TÉCNICAS

**Genzō — Bōgyo (Hakurō — defensivo):** Snow Cloak (15/min), Ice Coffin pequeno (40), Ice Coffin grande (80), Frost Veil (60+10/min), Hiraishin gelo curta (50), Hiraishin gelo longa (120), Ice Dragons (90), Battle Control (150+20/min), Clone gelo (45), Glacial Age (300 — congela 1km raio — PERIGO), Hyōton Rasengan (200 — Bijuu Bomb — PERIGO aliados), Invert no Jutsu (remove qualquer selo), Ghost Reveal (revela selos), Clone Relay Exchange (sem selos — não copiável por Sharingan), Manto (invisibilidade total), Bōgyo sensor 15km raio.

**Genzō — Kōgeki (Kiyomi — ofensivo):** Lâminas gelo (25), Ray of Frost (35), Ice Wolves (40), Genzō Vermelho/ira (80), Névoa Sangrenta Mimic (60), Rasengan via Portal (80).

**Andenryū (Kiyomi):** Portais — colapsa espaço A/B, requer âncora ou agulhas. Portal standard (30).

**Modo Sábio de Gelo (sem nome oficial):** Não é Modo Sábio tradicional — não absorve energia natural. Glacius fundiu chakra antigo com Bōgyo de Hakurō de dentro para fora. Força x3, processamento x2, armadura cristal, olhos de Glacius. Custo: nervos ópticos queimaram — cegueira permanente. Nunca aconteceu antes. Em treino para usar sem destruir os olhos.

**Bōgyo evoluído (pós-cegueira):** Fase actual: sente chakra, presença, temperatura. Mapeia quarto/campo. Em desenvolvimento: leitura contornos por chakra ambiental. Futuro: visão de chakra — vê intenção antes do movimento.

**Anulador (Ice Coffin — cave hospital):** Dojutsu do membro Akatsuki morto no arco Gaara. Anula chakra externo num raio. Olhos em Ice Coffin preservados. Decisão futura de Hakurō sobre transplante.

---

# 6. GLACIUS

Ser antigo anterior ao Genzō. Chakra próprio independente. Loba de gelo. Cresce com Hakurō.

**Fala verbalmente com:** Hakurō, Hinata, Kiyomi, Kakashi, Kurenai, Tsunade. Outros: sons animais.

**Capacidades:** Bafo Glaciar (80), Frost Bite (120 — congela chakra circulatório), Blizzard (300 — descanso 24h). Leitura profunda de chakra/intenção. Avalia candidatos Kansatsu-bu. Agência própria — não obedece cegamente.

**Primeira invocação:** Hakurō estava SOZINHO no campo de treino de Konoha. Hinata apareceu DEPOIS atraída pela queda de temperatura.

**Contrato:** Com o Bōgyo, não só com Hakurō — acesso por qualquer portador do Genzō.

---

# 7. FAMÍLIA — RUA HINOKI 7

**HINATA HYŪGA** — NOIVA. FUNDAÇÃO. Ritual de amor diário. Casamento 12 Novembro. Byakugan. Directora tesouraria Kansatsu-bu. Regra: sabe sempre tudo — antes ou durante, nunca depois sozinha. Filhos futuros: Haruto e Shiro (sem Genzō).

**KIYOMI YUKI SENJU** — IRMÃ GÉMEA. Andenryū. Chefe fiscalização. Humor seco. Possessiva de Hakurō. Dinâmica complexa: confusão mútua amor fraternal/atracção confirmada. Êxtase aconteceu. "Gostei mais do que devia." Linha: beijos e mão, sem penetração. Interesse em Neji não verbalizado. Dorme 2x/semana com Hakurō. Insónias quando ele está longe.

**TSUNADE** — MÃE ADOPTIVA. Hokage. Espaço sem nome — intimidade ocorreu. Agora: cuidado maternal predominante. "Preciso de dormir sozinha." Disse "Okaasan" aceitou.

**SHIZUNE** — TIA. Terceiro lugar. Intimidade consumada 2x. Só Hinata sabe.

**CHIE YUKA TERASHIMA** — IRMÃ (não prima). Hyōgi-kan Kiri. Cicatriz queixo esquerdo — Genzō de Hakurō com 4 anos. Mãe de Chie (Hana) morreu a salvar os gémeos.

**FUJINO** — ÂNCORA E IRMÃ INFORMAL APENAS. Ferreira. Chefe Dept. Científico. SEM dimensão romântica. NUNCA.

**DAICHI MIZUKI** (21) — Secretária/número dois. Sentimentos mútuos declarados. Hinata aceitou. Aguarda noite a três.

**YUA YUKI** (4) — Dorme com Hakurō e Hinata. Adoptada por Tsunade (pendente oficial). Kekkei Genkai espontâneo. Chama Hakurō de "mano." Hakurō é mais pai do que mano — ele não percebe, todos os outros percebem.

**SAKURA HARUNO** — Convidada de sábado. Médica de Hakurō (gesso). "A que não espera." Vai à sauna com Hinata. Traz mochi.

---

# 8. YUKIS DA CASA

Hakurō trata como irmãos/irmãs — NÃO filhos. Cuidado Yuki = familiar SEM conotação sexual.

| Nome | Idade | Estado |
|------|-------|--------|
| Mizuno Yuki | 12 | Em casa. Pai Rento em Konoha. Hyōton — rosas com espinhos. Quer ser Yuki-Senju. Diz "pai" em vez de "irmão" involuntariamente. |
| Sora Yuki | 14 | Anjo do mano. Sensor. Cabelo a ficar branco. Trauma Cofre — banho com esponja. Ciúme máximo de qualquer mulher perto de Hakurō. |
| Haki Yuki | 10 (RAPARIGA) | Cristais extraordinários nos olhos. KG a expandir aceleradamente. Pode precisar transfusão. |
| Kaito Yuki | 8 (RAPAZ) | Cristais. Sangue diluído. Frequentemente no colo de Sora. |
| Mizuki Yuki Senju | 16 | Em casa — alta recente. Cadeira de rodas. Meia-irmã/prima. 31 Outubro. Linhagem primordial — marcas mais antigas. |
| Yua Yuki | 4 | Ver acima. |
| Rei Yuki | 20 | Prima de sangue real. 12 anos sozinha. Beijo Yuki dado. A recuperar. Romance futuro pós-4ª Guerra. |
| Ryu Senju | 24 | Guarda do complexo. Sangue Senju 5%. "Meu Senju." |

---

# 9. RELAÇÕES ROMÂNTICAS

| Pessoa | Posição | Estado |
|--------|---------|--------|
| Hinata | FUNDAÇÃO | Noiva. Casamento 12 Nov. Haruto e Shiro. |
| Mira | Segunda oficial | Consumado. Ritual incluído. |
| Pakura | Noiva | Anel gelo. Grávida — Shiori (menina) ou Aruka (menino). Casamento pós-Shiori. |
| Shizune | Terceiro lugar | Consumado. Só Hinata sabe. |
| Tsunade | Espaço sem nome | Intimidade ocorreu. Agora maternal. |
| Mei | A crescer | Preliminares. Chave Kiri. "Fofinho." |
| Yugito | A desenvolver | Beijo no espaço entre (estado vegetativo). Setembro/Kumo. |
| Daichi | Pendente | Aguarda noite a três. |
| Kiyomi | Gémea complexa | Linha: beijos e mão. Sem penetração. |
| Rei | Futuro | Pós-4ª Guerra. Primeiros gémeos com Genzō. |
| Akane | Futuro | ANBU Pedra. Ainda não chegou. |

**Regras com Hinata:** 1) Hinata sabe sempre — antes ou durante. 2) Ritual completo só com lugar definido. 3) Pressão a acumular → Hinata primeiro. 4) Nunca mentir.

---

# 10. FILHOS E HERANÇA DO GENZŌ

Genzō passa apenas aos primeiros gémeos nascidos de DOIS Yukis puros. Hakurō + Rei = primeiros gémeos com Genzō da próxima geração. Haruto e Shiro (Hinata) = extraordinários mas SEM Genzō.

| Mãe | Filhos Previstos / Kekkei Genkai |
|-----|----------------------------------|
| Pakura Yuki Kariya | Shiori (menina) ou Aruka (menino). Hyōton + Scorch Release + KG novo (fusão dos dois opostos). |
| Hinata Hyūga | Haruto e Shiro. Byakugan + Hyōton. SEM Genzō. |
| Rei Yuki | Primeiros gémeos COM Genzō. |
| Mei Terumii (futuro) | Hyōton + Lava Release + Boil Release + possível 5º KG. Após falar com Hinata. |
| Yugito (futuro) | A desenvolver após Setembro/Kumo. |

---

# 11. PAI DE HAKURŌ E IRMÃO MAIS VELHO — SEGREDO

Pai de Hakurō: vendeu a aldeia aos assassinos para sobreviver. Queria eliminar os gémeos para libertar o Genzō — para uma mulher mais fácil de manipular. Shiori recusou ser manipulada e voltou-se contra ele. Pode ter outros filhos de outras mães — experiências para combinar Kekkei Genkais.

Irmão mais velho: Dark Ice — Genzō corrupto que combina fogo, terra e ar com gelo. Filho do mesmo pai, mãe diferente (Uchiha). Criado como experiência deliberada. Par de Tobi na Akatsuki — designado para neutralizar os gémeos. **HAKURŌ NÃO SABE QUE EXISTE.**

Sobre Mizuki: mesma data de nascimento (31 Outubro). Mãe de Hakurō tinha irmã gémea. Pai engravidou as duas ao mesmo tempo. Nasceram Hakurō, Kiyomi e Mizuki no mesmo dia. Mizuki = meia-irmã/prima. Linhagem primordial Yuki — marcas mais antigas que as de Hakurō. Nunca engravidou no Cofre. Descartada quando KG a envenenava.

---

# 12. KANSATSU-BU — ESTADO COMPLETO

## Os Três Hyōgi-kan
- **Hakurō** — Konoha (de baixa/em recuperação)
- **Pakura Yuki Kariya** — Suna (a liderar durante ausência)
- **Chie Yuka Terashima** — Kiri

## Tribunal de Deliberação — Três Juízes
- **Shimon Higashide** — indicado pelo conselho
- **Yugao Uzuki** — indicada por Hiashi
- **Anko Mitarashi** — indicada por Tsunade (marca Orochimaru removida, yin yang no lugar)
- Presidido por Hyōgi-kan (não vota)

## Equipa Completa

| Membro | Função / Aldeia |
|--------|----------------|
| Hakurō | Hyōgi-kan Konoha |
| Pakura Yuki Kariya | Hyōgi-kan Suna |
| Chie Yuka Terashima | Hyōgi-kan Kiri |
| Hinata | Tesouraria e protocolos — Konoha |
| Kiyomi | Fiscalização — Konoha |
| Daichi | Secretaria / número dois — Konoha |
| Shino | COM / cave — Konoha |
| Ino | COM / cave — Konoha |
| Kiba + Akamaru | Fiscalização privada — Konoha |
| Hideo | Análise — Konoha |
| Sora (sensor) | Sensorial independente — Konoha |
| Fujino | Chefe Departamento Científico — Konoha |
| Toru | Assistente Dep. Científico — Konoha |
| Shimon Higashide | Juiz Tribunal |
| Yugao Uzuki | Juíza Tribunal |
| Anko Mitarashi | Juíza Tribunal |
| Masa | Sombra de Kiyomi — ex-Root |
| Reo | COM Suna — sensor terra |
| Mira | COM Suna — sensor vento |
| Kaito (Suna) | Fiscalização Suna |
| Sen | Secretaria/fiscalização Suna |
| Daro | Arquivo central Suna |
| Daiki Mori | Fiscalização estado Kiri |
| Yuna Shiro | COM Kiri — permanente Konoha |
| Ren Tasaki | Arquivo/Análise Kiri — permanente Konoha |
| Ami Kudo | Fiscalização civil Kiri |
| Jorou Nishi | Operações Kiri |

## Receita

| Campo | Valor |
|-------|-------|
| Dívida ao conselho | PAGA |
| Receita mensal Konoha | 3.200 ryō (5 contratos privados) |
| Receita Suna | 1.600 ryō/mês |
| Receita Kiri | 1.600 ryō/mês |
| Total | 6.400 ryō/mês |
| Instalação Hyōga Kiri | 6.000 ryō — Outubro |

---

# 13. REFORMAS E PROTOCOLOS KIRI — 10 IMPLEMENTADOS

| Protocolo | Descrição |
|-----------|-----------|
| 1. Descanso Semanal | Sábado e domingo — serviços mínimos rotativos. |
| 2. Regulação de Pessoal | Avaliação semestral. Promoções por mérito documentado. |
| 3. Academia Especial | Kekkei Genkai ou capacidades excepcionais — formação inter-aldeias. |
| 4. Migração Profissional | Processo standardizado entre aldeias parceiras. |
| 5. Fronteiras sem Fronteiras | Shinobis Kansatsu-bu circulam livremente em missão oficial. |
| 6. Acordos Comerciais Simétricos | Mesmas taxas nas duas direcções entre aldeias parceiras. |
| 7. Protecção Civis Conflito | Evacuação obrigatória antes de operação militar em zona habitada. |
| 8. Registo Kekkei Genkai | Base dados partilhada — protecção e apoio médico. NÃO perseguição. |
| 9. Comunicação Emergência | Via Hyōga — linha directa sem protocolo diplomático prévio. |
| 10. Transparência Orçamental | Relatórios semestrais públicos — auditados Kansatsu-bu. |

Implementação: 100% concluída em Kiri por 15 clones de Hakurō. Fotos dos três Hyōgi-kan em todos os edifícios estatais de Kiri.

## Requisitos para ser Hyōgi-kan
1. Não querer o cargo — ambição é critério de exclusão imediata.
2. Lealdade demonstrada sem recompensa esperada.
3. Capacidade de ver o que outros não veem.
4. Ter recusado poder fácil quando oferecido.
5. Nome com peso sem ambição dinástica.
6. Unanimidade dos três pilares para eleger E para remover.
Nota Tobirama: "Só funciona se a pessoa não quiser mais do que isto. O maior perigo é a ambição."

## Três Pilares de Kiri
| Pilar | Quem |
|-------|------|
| 1º Pilar | Mizukage — Mei Terumii |
| 2º Pilar | Conselho dos Veteranos |
| 3º Pilar | Chōjūrō — voz do povo |

---

# 14. ORGANIZAÇÃO KONTON — INIMIGO

Caçadores de Kekkei Genkai — activos há 20 anos. Conselho de 5 membros — nunca vistos. Símbolo: serpente a engolir a própria cauda. Intermediário Ryuken — identificado e entregue a Mei. O Cofre destruído. 3 responsáveis em frost coffin → Hokage. Reunião anual: Outubro — lua cheia. Ilha sem nome entre País da Água e País do Relâmpago.

---

# 15. ALIADOS E INIMIGOS

**Konoha:** Tsunade (confiança total), Kakashi (respeito profissional, cristal activo), Shikamaru (aliado estratégico), Neji (aliado real — Kiyomi interessada), Hiashi (disse "filho" à saída do jantar), Hanabi ("bem-vindo à família"), Sakura (convidada de sábado), Iruka (tutor), Shikaku/Hiashi/Inoichi (sala privada — sabem da operação Root).

**Outras aldeias:** Mei (casa partilhada), Pakura (noiva, grávida, Hyōgi-kan), Yugito (a recuperar, beijo no espaço entre), Chōjūrō (terceiro pilar Kiri).

**Inimigos:**
- **Danzō** — afastado do conselho. Caso no Tribunal. 20 agentes Root em observação. Não sabe: rede Hyōga, Hiraishin, descobertas Tobirama.
- **Konton** — base destruída. Reunião Outubro.
- **Akatsuki / Tobi** — recuou. "Vemo-nos em breve." Identidade: Obito — **DESCONHECIDO PARA TODOS NO UNIVERSO ATÉ QUE O CANON O INTRODUZA.**
- **Irmão mais velho (Dark Ice + Sharingan)** — par de Tobi. Hakurō NÃO sabe que existe.

---

# 16. O QUE KONOHA SABE / NÃO SABE

**Sabe:** Yuki chegou em estado crítico. Com herdeira Hyūga. Prodígio de infiltração. Kekkei Genkai de gelo. Hyōgi-kan aprovado.

**Não sabe:** Rede Hyōga real, Hiraishin de gelo, descobertas Tobirama, que detectou 61 Sharingan de Danzō.

**Danzō sabe:** Existe Yuki em Konoha, Tsunade protege-o directamente. Suspeita que foi detectado. Não sabe: rede Hyōga, Hiraishin, Tobirama.

---

# 17. CALENDÁRIO — PASSADO E FUTURO

| Data | Evento |
|------|--------|
| Agosto (passado) | Semana Kiri. Noivado Pakura. Primeira vez Mira. Yukis encontrados. Arco Yugito/Akatsuki. |
| Setembro (AGORA) | Hakurō acorda do coma. Hospital Konoha. |
| Setembro | Visita a Kumo — Yugito. Reunião Raikage. |
| Em breve | Chegada de Akane (ANBU Pedra). |
| Outubro | Instalação Hyōga Kiri. Operação Konton — ilha sem nome. |
| 12 Novembro | CASAMENTO Hakurō + Hinata — confirmado. |
| Pós-Shiori | Casamento Hakurō + Pakura. |
| Futuro | Arco Pain — Hakurō morre a proteger Hinata, ressuscitado por Nagato. |
| Futuro | 4ª Guerra — Neji salvo por Kiyomi. Arco romântico Kiyomi/Neji. |
| Futuro | Gémeos Haruto e Shiro (Hakurō+Hinata). |
| Futuro | Irmão mais velho revelado. |
| Futuro | Rei + Hakurō — primeiros gémeos com Genzō da próxima geração. |

---

# 18. TRADIÇÕES YUKI-SENJU

- Beijo família: na boca, gesto de clã SEM conotação romântica
- Beijo esquimó: reconhecimento profundo, não romântico
- Cuidado Yuki (lavar, massajar, colo): gesto familiar SEM conotação sexual
- Linguagem íntima: Sentinela=pénis, Pérola=vagina, Tesouro=órgãos
- Dentes aguçados: traço do clã, raramente mostrado
- Chefe da casa: portador do Genzō — autoridade de clã

---

*O mundo tem memória perfeita. Nada foi esquecido.*
